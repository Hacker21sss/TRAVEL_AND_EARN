const Traveldetails = require('../model/traveldetails'); // Adjust path
const Driver = require('../../traveller/model/traveller'); // New Driver model for managing drivers
const mapservice = require('../../service/mapservice');

// Create Travel Detail
exports.createTravelDetail = async (req, res) => {
  const { Leavinglocation, Goinglocation, travelDate } = req.body;

  // Validation check
  if (!Leavinglocation || !Goinglocation) {
    return res.status(400).json({ message: 'Leaving and Going locations are required' });
  }

  try {
    // Fetch coordinates for Leaving and Going locations
    const leavingCoordinates = await mapservice.getAddressCoordinate(Leavinglocation);
    const goingCoordinates = await mapservice.getAddressCoordinate(Goinglocation);

    if (!leavingCoordinates || !goingCoordinates) {
      return res.status(400).json({ message: 'Unable to fetch coordinates for the provided locations.' });
    }

    // Find captains within a 5 km radius of Leaving location
    const captainsInRadius = await mapservice.getCaptainsInTheRadius(
      leavingCoordinates.ltd,
      leavingCoordinates.lng,
      5 // Radius in km
    );

    console.log('Captains found within 5 km:', captainsInRadius);

    // Save travel details to the database
    const newTravelDetail = new Traveldetails({
      Leavinglocation,
      Goinglocation,
      travelDate,
      captainsNearby: captainsInRadius,
    });

    if (captainsInRadius.length === 0) {
      return res.status(404).json({ message: 'No available captains found in the radius' });
    }

    await newTravelDetail.save();

    return res.status(201).json({
      message: 'Travel detail created successfully',
      travelDetail: newTravelDetail,
      captains: captainsInRadius,
    });
  } catch (error) {
    console.error('Error creating travel detail:', error.message);
    res.status(500).json({ message: 'Error creating travel detail', error: error.message });
  }
};

// Search Nearest Available Drivers
exports.searchNearestDrivers = async (req, res) => {
  const { Leavinglocation, Goinglocation, travelDate } = req.body;

  if (!Leavinglocation || !Goinglocation || !travelDate) {
    return res.status(400).json({ message: 'Leaving location, Going location, and Travel Date are required.' });
  }

  try {
    // Fetch coordinates of Leaving location
    const leavingCoordinates = await mapservice.getAddressCoordinate(Leavinglocation);
    if (!leavingCoordinates) {
      return res.status(400).json({ message: 'Invalid Leaving location.' });
    }

    // Find available drivers within a 5 km radius
    const availableDrivers = await mapservice.getCaptainsInTheRadius(
      leavingCoordinates.ltd,
      leavingCoordinates.lng,
      5
    );

    if (!availableDrivers || availableDrivers.length === 0) {
      return res.status(404).json({ message: 'No available drivers found nearby.' });
    }

    return res.status(200).json({
      message: 'Available drivers found.',
      availableDrivers,
    });
  } catch (error) {
    console.error('Error searching for nearest drivers:', error.message);
    return res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

// Send Request to Chosen Driver
exports.requestDriver = async (req, res) => {
  const { driverId, Leavinglocation, Goinglocation, travelDate } = req.body;

  if (!driverId || !Leavinglocation || !Goinglocation || !travelDate) {
    return res.status(400).json({ message: 'Driver ID, Leaving location, Going location, and Travel Date are required.' });
  }

  try {
    // Fetch driver details
    const driver = await Driver.findById(driverId);
    if (!driver) {
      return res.status(404).json({ message: 'Driver not found.' });
    }

    // Create new travel detail
    const newTravelDetail = new Traveldetails({
      Leavinglocation,
      Goinglocation,
      travelDate,
      driverId,
      status: 'Pending', // Initial status
    });

    await newTravelDetail.save();

    console.log(`Request sent to Driver: ${driver.name}`);

    return res.status(200).json({
      message: 'Request sent successfully to the driver.',
      travelDetail: newTravelDetail,
    });
  } catch (error) {
    console.error('Error requesting driver:', error.message);
    return res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

// Get All Travel Details
exports.getAllTravelDetails = async (req, res) => {
  try {
    const travelDetails = await Traveldetails.find().sort({ createdAt: -1 });
    res.status(200).json(travelDetails);
  } catch (err) {
    console.error('Error fetching travel details:', err);
    res.status(500).json({ message: 'Internal server error', error: err.message });
  }
};

// Get Travel Detail by ID
exports.getTravelDetailById = async (req, res) => {
  try {
    const { id } = req.params;

    const travelDetail = await Traveldetails.findById(id);
    if (!travelDetail) {
      return res.status(404).json({ message: 'Travel detail not found' });
    }

    res.status(200).json(travelDetail);
  } catch (err) {
    console.error('Error fetching travel detail:', err);
    res.status(500).json({ message: 'Internal server error', error: err.message });
  }
};

// Update Travel Detail
exports.updateTravelDetail = async (req, res) => {
  try {
    const { id } = req.params;
    const { Leavinglocation, Goinglocation, travelDate } = req.body;

    const travelDetail = await Traveldetails.findById(id);
    if (!travelDetail) {
      return res.status(404).json({ message: 'Travel detail not found' });
    }

    travelDetail.Leavinglocation = Leavinglocation || travelDetail.Leavinglocation;
    travelDetail.Goinglocation = Goinglocation || travelDetail.Goinglocation;
    travelDetail.travelDate = travelDate || travelDetail.travelDate;

    await travelDetail.save();
    res.status(200).json({ message: 'Travel detail updated successfully', travelDetail });
  } catch (err) {
    console.error('Error updating travel detail:', err);
    res.status(500).json({ message: 'Internal server error', error: err.message });
  }
};

// Delete Travel Detail
exports.deleteTravelDetail = async (req, res) => {
  try {
    const { id } = req.params;

    const travelDetail = await Traveldetails.findByIdAndDelete(id);
    if (!travelDetail) {
      return res.status(404).json({ message: 'Travel detail not found' });
    }

    res.status(200).json({ message: 'Travel detail deleted successfully' });
  } catch (err) {
    console.error('Error deleting travel detail:', err);
    res.status(500).json({ message: 'Internal server error', error: err.message });
  }
};
