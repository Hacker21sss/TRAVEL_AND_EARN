// controllers/userController.js
const User1 = require("../model/User");
const Otp = require('../model/Otp');
const admin = require("../../config/firebaseconfig"); // Import Firebase config
const crypto = require("crypto");

// Generate OTP
const generateOtp = () => Math.floor(100000 + Math.random() * 900000);

// Send OTP to user (via Firebase or alternative SMS provider)
exports.sendOtp = async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    const otp = generateOtp();

    // Check if user exists
    let user = await User1.findOne({ phoneNumber });
    if (!user) {
      // Create new user if not exists
      user = new User1({ phoneNumber, otp });
    } else {
      // Update OTP if user exists
      user.otp = otp;
    }

    await user.save();

    // Here, we would use Firebase or any SMS service to send the OTP
    const phoneAuth = await admin.auth().createUser({ phoneNumber });
    // Mock success response for sending OTP (replace with actual SMS sending logic in production)
    console.log(otp);
    res.status(200).json({ message: "OTP sent successfully", otp }); // Note: In production, don't send the OTP back

  } catch (error) {
    console.error("Error sending OTP:", error);
    res.status(500).json({ error: "Error sending OTP" });
  }
};

// Verify OTP
exports.verifyOtp = async (req, res) => {
  try {
    const { phoneNumber, otp } = req.body;

    // Find user by phone number
    const user = await User1.findOne({ phoneNumber });
    if (!user) {
      return res.status(400).json({ error: "User not found" });
    }

    // Verify OTP explicitly
    if (user.otp !== otp) {
      return res.status(400).json({ error: "Invalid OTP" });
    }

    // Clear OTP directly in the database
    await User1.updateOne({ phoneNumber }, { otp: null });

    res.status(200).json({ message: "OTP verified successfully" });
  } catch (error) {
    console.error("Error verifying OTP:", error);
    res.status(500).json({ error: "Error verifying OTP" });
  }
};
