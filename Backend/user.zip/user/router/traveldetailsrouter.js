const express = require('express');
const router = express.Router();
const travelController = require('../../user/controller/TraveldetailsController');

router.post('/create', travelController.createTravelDetail);
router.post('/searchNearestDrivers', travelController.searchNearestDrivers);
router.post('/requestDriver', travelController.requestDriver);
router.get('/', travelController.getAllTravelDetails);
router.get('/:id', travelController.getTravelDetailById);
router.put('/:id', travelController.updateTravelDetail);
router.delete('/:id', travelController.deleteTravelDetail);

module.exports = router;
