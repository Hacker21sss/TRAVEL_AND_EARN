const mongoose = require('mongoose');

const TraveldetailsSchema = new mongoose.Schema({
  // userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  Leavinglocation:{type:String,required:true},
  Goinglocation:{type:String,required:true}, // Status: Pending, In Progress, Resolved
  travelMode: { type: String,  },
  travelDetails: { type: String },
  travelDate: { type: Date,  required:true },
  coordinates: { type: Array, default: [] }, // To store real-time tracking points
}, { timestamps: true });

module.exports = mongoose.model('Traveldetails', TraveldetailsSchema);
